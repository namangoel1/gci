# GCI Database
A simple node app that saves basic student info to a mongodb database. [Task](https://www.google-melange.com/gci/task/view/google/gci2014/5852137653272576)

## Set up

* `npm install`
* Run `mongo` somewhere
* `mongod --dbpath data` 
* `node ./bin/www`

All three are independent, continuous processes, and will need separate windows to run.
